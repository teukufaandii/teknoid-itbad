<?php
session_start(); // Mulai sesi jika belum dimulai
include "logout-checker.php";
// Database connection
$servername = "localhost";
$username = "root"; // your MySQL username
$password = ""; // your MySQL password
$dbname = "db_teknoid"; // your database name
$conn = new mysqli($servername, $username, $password, $dbname);

require __DIR__ . '/twilio-app/vendor/autoload.php';

// Twilio credentials
$twilioAccountSid = 'ACa7e1267f7df10a6b837cb2583b7ed409';
$twilioAuthToken = 'c016f6bdb18bd873090364f272568a57';
$twilioPhoneNumber = '+14155238886'; // Your Twilio phone number for WhatsApp

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function sendWhatsAppMessage($to, $message) {
    global $twilioAccountSid, $twilioAuthToken, $twilioPhoneNumber;
    
    // Initialize Twilio client
    $twilio = new Twilio\Rest\Client($twilioAccountSid, $twilioAuthToken);
    
    try {
        // Send WhatsApp message
        $message = $twilio->messages->create("whatsapp:$to", // to
                                              [
                                                  "from" => "whatsapp:$twilioPhoneNumber", // from
                                                  "body" => $message,
                                              ]
                                             );
        return $message->sid; // Return message SID on success
    } catch (Exception $e) {
        return false; // Return false on failure
    }
}

// Fungsi untuk menghasilkan angka romawi dari angka biasa
function intToRoman($num) {
    $n = intval($num);
    $res = '';

    // Array untuk konversi angka romawi
    $roman_numerals = array(
        'M'  => 1000,
        'CM' => 900,
        'D'  => 500,
        'CD' => 400,
        'C'  => 100,
        'XC' => 90,
        'L'  => 50,
        'XL' => 40,
        'X'  => 10,
        'IX' => 9,
        'V'  => 5,
        'IV' => 4,
        'I'  => 1
    );

    foreach ($roman_numerals as $roman => $number) {
        // Hitung jumlah simbol romawi yang diperlukan
        $matches = intval($n / $number);
        // Tambahkan simbol romawi ke hasil
        $res .= str_repeat($roman, $matches);
        // Kurangi nilai yang telah ditambahkan ke hasil dari nilai asli
        $n = $n % $number;
    }

    return $res;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    // Ambil nilai input dari form
    $asal_surat = $_POST['asal_surat'];
    $tujuan_surat = $_POST['tujuan_surat'];
    $deskripsi = $_POST['deskripsi'];
    $no_hp = $_POST['no_hp'];
    $id_jenis_surat = $_POST['jenis_surat']; // Mengambil id jenis surat yang dipilih
    $perihal = $_POST['perihal'];
    $tanggal_surat = date("Y-m-d");
    $no_surat = $_POST['no_surat'];

    // Mendapatkan nomor surat terakhir untuk bulan ini
    $current_month = date('n');
    $query_last_number = "SELECT MAX(SUBSTRING(kode_surat, 1, 3)) AS last_number FROM tb_surat_dis WHERE MONTH(tanggal_surat) = '$current_month'";
    $result_last_number = $conn->query($query_last_number);
    $last_number_row = $result_last_number->fetch_assoc();
    $last_number = $last_number_row['last_number'];

    // Jika tidak ada nomor surat untuk bulan ini, atur ke 0
    if ($last_number === null) {
        $last_number = 0;
    }

    // Nomor surat berikutnya
    $next_number = intval ($last_number) + 1;
    // Format nomor surat agar menjadi 3 digit dengan leading zeros
    $next_number_formatted = sprintf('%03d', $next_number);
    // Konversi angka bulan menjadi angka romawi
    $roman_month = intToRoman($current_month);
    // Tahun saat ini
    $current_year = date('Y');

    // Kode surat otomatis
    $kode_surat_otomatis = "$next_number_formatted/ITBAD/$roman_month/$current_year";

    // Move uploaded files to desired location
    $upload_berkas_dir = "uploads/berkas/";
    $upload_laporan_dir = "uploads/laporan/";

    // Check if both files are uploaded or not
    $is_berkas_uploaded = !empty($_FILES['file_berkas']['name']) && is_uploaded_file($_FILES['file_berkas']['tmp_name']);
    $is_laporan_uploaded = !empty($_FILES['file_laporan']['name']) && is_uploaded_file($_FILES['file_laporan']['tmp_name']);

    if (!$is_berkas_uploaded && !$is_laporan_uploaded) {
        echo "Maaf, anda harus mengunggah setidaknya satu file (berkas atau laporan).";
        exit();
    }

    // Validasi ukuran file
    $max_file_size = 10 * 1024 * 1024; // 10MB dalam byte
    if ($is_berkas_uploaded && $_FILES['file_berkas']['size'] > $max_file_size) {
        echo "Maaf, ukuran file berkas surat tidak boleh melebihi 10MB.";
        exit();
    }

    if ($is_laporan_uploaded && $_FILES['file_laporan']['size'] > $max_file_size) {
        echo "Maaf, ukuran file laporan tidak boleh melebihi 10MB.";
        exit();
    }

    // Insert data into database
    $sql = "INSERT INTO tb_surat_dis (asal_surat, kode_surat, tujuan_surat, no_hp, perihal, nomor_surat, jenis_surat, tanggal_surat, deskripsi) 
            VALUES ('$asal_surat', '$kode_surat_otomatis', '$tujuan_surat', '$no_hp', '$perihal', '$no_surat', '$id_jenis_surat', '$tanggal_surat', '$deskripsi')";
            
    $notification_message = "Surat baru telah masuk:\n\nAsal Surat: $asal_surat\nTujuan Surat: $tujuan_surat\nPerihal: $perihal\n\nMohon Ditanggapi";
    $notification_recipient = '+6285213042065'; // Change to your desired recipient's phone number
    $notification_sent = sendWhatsAppMessage($notification_recipient, $notification_message);
    if ($notification_sent) {
        echo '<script>alert("Surat berhasil dikirim");</script>';
    } else {
        echo '<script>alert("Data berhasil disimpan, tetapi gagal mengirim notifikasi WhatsApp.")</script>';
    }

    if ($conn->query($sql) === TRUE) {
        // Ambil ID surat yang baru saja dimasukkan
        $id_surat_baru = $conn->insert_id;

        // Simpan informasi file berkas ke dalam tabel file_berkas
        // Simpan informasi file berkas ke dalam tabel file_berkas
        if ($is_berkas_uploaded) {
            $file_berkas_name = uniqid() . '_' . $_FILES['file_berkas']['name']; // Mendapatkan nama file yang diunggah
            $sql_file_berkas = "INSERT INTO file_berkas (id_surat, nama_berkas) VALUES ('$id_surat_baru', '$file_berkas_name')";
            $conn->query($sql_file_berkas);
            move_uploaded_file($_FILES['file_berkas']['tmp_name'], $upload_berkas_dir . $file_berkas_name); // Simpan file dengan nama yang sesuai
        }

        // Simpan informasi file laporan ke dalam tabel file_laporan
        if ($is_laporan_uploaded) {
            $file_laporan_name = $_FILES['file_laporan']['name'];
            $sql_file_laporan = "INSERT INTO file_laporan (id_surat, nama_laporan) VALUES ('$id_surat_baru', '$file_laporan_name')";
            $conn->query($sql_file_laporan);
            move_uploaded_file($_FILES['file_laporan']['tmp_name'], $upload_laporan_dir . $file_laporan_name);
        }

        $update_url_sql = "UPDATE tb_surat_dis SET diteruskan_ke = 'Rektor' WHERE id_surat = '$id_surat_baru'";
        if ($conn->query($update_url_sql) === TRUE)

        echo "<script> setTimeout(function() {
            window.location.href = 'surat_keluar.php';}, 1000);
            </script>";
} else {
// Tampilkan pesan error SQL
echo "Error: " . $sql . "<br>" . $conn->error;
}}
?>

<!doctype html>
<html lang="en">
<head>
    <title>Tambah Surat - Teknoid</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/x-icon" href="../logo itbad.png">
    <link href="css/dashboard-style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <!-- sidenav -->
    <?php include "sidenav.php" ?>

    <!-- content --> 
    <div class="content" id="Content">
        <!-- topnav -->
        <?php include "topnav.php" ?>
        
        <div class="mainContent" id="mainContent">
            <div class="contentBox">
                <div class="pageInfo">  
                    <h3>Tambah Surat</h3>
                   <a href="surat_keluar.php"> <button class="back">Kembali</button> </a> 
                </div>
                <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" class="form" enctype="multipart/form-data">
                    <div class="inputfield">
                        <label for="">Jenis Surat*</label>
                        <div class="custom_select">
                            <select name="jenis_surat" id="jenis_surat">
                                <?php
                                    // Query untuk mendapatkan jenis surat dari tabel tb_jenis
                                    $query_jenis_surat = "SELECT * FROM tb_jenis LIMIT 2";
                                    $result_jenis_surat = $conn->query($query_jenis_surat);
                                    
                                    // Periksa apakah ada hasil query
                                    if ($result_jenis_surat->num_rows > 0) {
                                        // Loop melalui setiap baris hasil query
                                        while($row_jenis_surat = $result_jenis_surat->fetch_assoc()) {
                                            // Tampilkan opsi jenis surat
                                            echo "<option value='" . $row_jenis_surat['kd_jenissurat'] . "'>" . $row_jenis_surat['nama_jenis'] . "</option>";
                                        }
                                    } else {
                                        echo "<option value=''>Tidak ada jenis surat yang tersedia</option>";
                                    }
                                    ?>
                            </select>
                        </div>
                    </div>

                    <div class="inputfield">
                        <label for="">Asal Surat</label>
                        <input class="input" type="text" name="asal_surat" value="<?php echo isset($_SESSION['nama_lengkap']) ? $_SESSION['nama_lengkap'] : ''; ?>" readonly>
                    </div> 

                    <div class="inputfield">
                        <label for="">Perihal*</label>
                        <input type="text" class="input" name="perihal" placeholder="Masukkan Perihal" autocomplete="off" required>
                    </div>

                    <div class="inputfield">
                            <label for="">Nomor Surat</label>
                            <input type="text" class="input" name="no_surat" placeholder="Masukkan Nomor Surat">
                    </div>

                    <div class="inputfield">
                        <label for="">Tujuan Surat*</label>
                        <div class="custom_select">
                            <select type="text" class="input" name="tujuan_surat" placeholder="Masukkan Tujuan Surat" autocomplete="off" required>
                                <option hidden disabled selected value="">Pilih Unit</option>
                                <option>Rektor</option>
                                <option>Wakil Rektor 1</option>
                                <option>Wakil Rektor 2</option>
                                <option>Wakil Rektor 3</option>
                                <option>Direktur Pasca Sarjana</option>
                                <option>Dekan FTD</option>
                                <option>Dekan FEB</option>
                                <option>Prodi S2 Keuangan Syariah</option>
                                <option>Prodi S1 Sistem Informasi</option>
                                <option>Prodi S1 Teknologi Informasi</option>
                                <option>Prodi S1 Desain Komunikasi Visual</option>
                                <option>Prodi S1 Arsitektur</option>
                                <option>Prodi S1 Manajemen</option>
                                <option>Prodi S1 Akuntansi</option>
                                <option>Prodi D3 Akuntansi</option>
                                <option>Prodi D3 Keuangan dan Perbankan</option>
                                <option>Unit Humas</option>
                                <option>Unit Keuangan</option>
                                <option>Unit Umum</option>
                                <option>Unit Marketing</option>
                                <option>Unit BPM</option>
                                <option>Unit Akademik</option>
                                <option>Unit Perpustakaan</option>
                                <option>Unit LP3M</option>
                                <option>Unit KUI dan Kerjasama</option>
                                <option>Unit PPIK dan Kemahasiswaan</option>
                                <option>Unit IT & Laboratorium</option> 
                                <!-- Daftar tujuan surat lainnya -->
                            </select>

                            <script>
                                document.addEventListener("DOMContentLoaded", function() {
                                var select = document.getElementById("unitSelect");
                                
                                select.addEventListener("change", function() {
                                    if (this.value === "") {
                                    this.selectedIndex = -1; // Reset the selected index to none
                                    }
                                });
                                });
                            </script>

                        </div>
                    </div>
                    <div class="inputfield">
                        <label for="">Nomor Telepon*</label>
                        <input type="number" class="input" name="no_hp" placeholder="Masukkan Nomor Telepon" value="<?php echo isset($_SESSION['phone_number']) ? $_SESSION['phone_number'] : ''; ?>" required>
                    </div>

                    <div class="inputfield">
                        <label for="">Deskripsi Singkat*</label>
                        <input type="text" class="input" name="deskripsi" placeholder="Masukkan Deskripsi Singkat" autocomplete="off" maxlength="100" required>
                    </div>

                    <div class="inputfield">
                        <label for="">Unggah Berkas Surat</label>
                        <input type="file" class="input" name="file_berkas" accept="application/pdf" style="border: none;" required>
                        <p style="color: red;"> *Ukuran Max 10Mb (PDF)</p>
                    </div>

                    <div class="inputfieldhidden" id="uploadBerkasLaporan" style="display: none;"> 
                        <div class="inputfield">
                            <label for="">Unggah Berkas Laporan</label>
                            <input type="file" class="input" name="file_laporan" accept="application/pdf" style="border: none;">
                            <p style="color: red;"> *Ukuran Max 10Mb (PDF)</p>
                        </div>
                    </div>

                    <div class="btn-kirim">
                        <div class="floatFiller">ff</div>
                        <input id="submitForm" type="submit" name="submit" value="Kirim" style="display: none;">
                        <button class="btn" type="button" onclick="showConfirmationPopup()">Kirim</button>
                    </div>
                </form>
                
            </div>
        </div>
        <?php include './footer.php'; ?>
    </div>

    <script>
        // Function to show SweetAlert confirmation popup
        function showConfirmationPopup() {
            Swal.fire({
                title: 'Konfirmasi?',
                text: 'Anda yakin ingin mengirim surat?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, kirim!',
                cancelButtonText: 'Tidak, periksa kembali',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    // If confirmed, trigger form submission
                    document.getElementById('submitForm').click();
                }
            });
        }

        // Function to handle form submission response
        function handleFormSubmissionResponse(success) {
            if (success) {
                Swal.fire({
                    title: 'Success!',
                    text: 'The letter has been sent successfully.',
                    icon: 'success'
                });
            } else {
                Swal.fire({
                    title: 'Error!',
                    text: 'Failed to send the letter. Please try again later.',
                    icon: 'error'
                });
            }
        }
    </script>

    <script>
            document.addEventListener("DOMContentLoaded", function() {
                var jenisSuratDropdown = document.getElementById('jenis_surat');
                var uploadBerkasLaporan = document.getElementById('uploadBerkasLaporan');

                // Event listener untuk perubahan pada dropdown jenis surat
                jenisSuratDropdown.addEventListener('change', function() {
                    var selectedOption = this.value;

                    // Tampilkan elemen unggah berkas laporan jika jenis surat yang dipilih adalah "Surat Laporan" (nilai 2)
                    if (selectedOption === '2') {
                        uploadBerkasLaporan.style.display = 'block';
                        // Tambahkan atribut required ke input file laporan
                        document.querySelector('input[name="file_laporan"]').setAttribute('required', 'required');
                    } else {
                        uploadBerkasLaporan.style.display = 'none';
                        // Hapus atribut required dari input file laporan jika jenis surat yang dipilih bukan "Surat Laporan"
                        document.querySelector('input[name="file_laporan"]').removeAttribute('required');
                    }
                });

                // Inisialisasi tampilan berdasarkan nilai default dropdown saat halaman dimuat
                var initialOption = jenisSuratDropdown.value;
                if (initialOption === '2') {
                    uploadBerkasLaporan.style.display = 'block';
                    document.querySelector('input[name="file_laporan"]').setAttribute('required', 'required');
                } else {
                    uploadBerkasLaporan.style.display = 'none';
                    document.querySelector('input[name="file_laporan"]').removeAttribute('required');
                }
            });

    </script>
    <script src="js/dashboard-js.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    
</body>
</html>

<?php
// Tutup koneksi database
$conn->close();
?>