<!DOCTYPE html>
<html lang="eng">
<?php 
session_start();
include 'koneksi.php';
include "logout-checker.php";
// Periksa apakah session username telah diatur
if (!isset($_SESSION['pengguna_type'])) {
    echo '<script language="javascript" type="text/javascript">
    alert("Anda Tidak Berhak Masuk Kehalaman Ini!");</script>';
    echo "<meta http-equiv='refresh' content='0; url=../index.php'>";
    exit;
}

$id = $_GET['id'] ?? null;

// Fetch data from the first table based on the provided ID
$sql1 = "SELECT sd.kode_surat, sd.nama_lengkap, sd.nim, sd.tanggal_surat, sd.tujuan_surat, sd.asal_surat, j.nama_jenis,
                sd.perihal, sd.nomor_surat, sd.no_hp, sd.email, sd.deskripsi
         FROM tb_surat_dis sd
         INNER JOIN tb_jenis j ON sd.jenis_surat = j.kd_jenissurat
         WHERE sd.id_surat = ?";

$stmt1 = $koneksi->prepare($sql1);
$stmt1->bind_param("i", $id);
$stmt1->execute();
$stmt1->bind_result($kode_surat, $nama_lengkap, $nim, $tanggal_surat, $tujuan_surat, $asal_surat, $jenis_surat,
                    $perihal, $no_surat, $no_telepon, $suratelektrik, $deskripsi);
$stmt1->fetch();
$stmt1->close();

$sql2 = "SELECT dispo1, dispo2, dispo3, catatan_disposisi, catatan_disposisi2 FROM tb_disposisi WHERE id_surat = ?";
$stmt2 = $koneksi->prepare($sql2);
$stmt2->bind_param("i", $id);
$stmt2->execute();
$stmt2->bind_result($disposisi1, $disposisi2, $disposisi3, $catatan_disposisi, $catatan_disposisi2);
$stmt2->fetch();
$stmt2->close();

$sql3 = "SELECT nama_berkas FROM file_berkas WHERE id_surat = ?";
$stmt3 = $koneksi->prepare($sql3);
$stmt3->bind_param("i", $id);
$stmt3->execute();
$stmt3->bind_result($file_berkas_name);
$stmt3->fetch();
$stmt3->close();

$sql4 = "SELECT nama_laporan FROM file_laporan WHERE id_surat = ?";
$stmt4 = $koneksi->prepare($sql4);
$stmt4->bind_param("i", $id);
$stmt4->execute();
$stmt4->bind_result($file_laporan_name);
$stmt4->fetch();
$stmt4->close();

// Check if files exist
$file_berkas_exists = !empty($file_berkas_name);
$file_laporan_exists = !empty($file_laporan_name);
?>

    <head>
        <title>Disposisi - Teknoid</title>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="icon" type="image/x-icon" href="../logo itbad.png">
        <link href="css/dashboard-style.css" rel="stylesheet">
        <link href="css/disposisi-style.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
        
        
        
        <style>
        /* Style untuk modal-content */
        .modal-content-file {
            background-color: whitesmoke;
            margin: auto;
            height: 85vh;
            width: 80%;
            display: flex;
            flex-direction: column;
            backdrop-filter: blur(5px); /* Apply blur effect */
        }

        .modal .modal-content-file h2 {
          color: black;
          padding-top: 20px;
        }

        /* Style untuk tombol close */
        .close {
            color: #aaa;
            float: right;
            padding-right: 5vw;
            margin-right: 0px;
            font-size: 35px;
            font-weight: bold;
            color: red;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        /* Style untuk iframe di dalam modal tampilan laporan */
        iframe{
            border: 1px solid black;
        }
        #berkasFrame,
        #laporanFrame {
            width: 90%;
            height: 60vh;
            margin: auto;
        }
        @media (max-width: 600px) {
            .modal-content-file {
                width: 90%;
                height: 70vh;
            }

            #berkasFrame,
            #laporanFrame {
                width: 90%;
                height: 60vh;
                margin: auto;
            }

            .close {
                font-size: 25px;
                margin-right: 10px;
            }
        }
        </style>
    
    </head>
    <body>
        <!-- sidenav -->
        <?php include "sidenav.php" ?>

        <!-- content --> 
        <div class="content" id="Content">
            <!-- topnav -->
            <?php include "topnav.php" ?>
            
            <div class="mainContent" id="mainContent">
                <div class="contentBox">
                    <div class="pageInfo">  
                        <h3>Disposisi - <?php echo $_SESSION['jabatan'] ?></h3>
                        <a href="surat_masuk.php"><button class="back">Kembali</button></a>
                    </div>
                        <form class="form">
                                <div class="input-field">
                                    <label for="">Kode Surat</label>
                                    <input type="text" class="input" name="#" placeholder="" value="<?php echo $kode_surat; ?>" readonly>
                                </div>

                                <div class="input-field">
                                    <label for="">Jenis Surat</label>
                                    <input type="text" class="input" name="#" placeholder="" value="<?php echo $jenis_surat; ?>" readonly>
                                </div>

                                <div class="input-field">
                                    <label for="">Asal Surat</label>
                                    <input type="text" class="input" name="#" value="<?php echo $asal_surat; ?>" readonly>
                                </div>

                                <?php if ($_SESSION['akses'] == "Humas" || $_SESSION['akses'] == "Sekretaris") { ?>
                                <div class="input-field">
                                    <label for="">Nama Siswa</label>
                                    <input type="text" class="input" name="#" value="<?php echo (is_array($nama_lengkap) ? $nama_lengkap[0] : $nama_lengkap); ?>" readonly>
                                </div>
                                

                                <div class="input-field">
                                    <label for="">NIM Siswa</label>
                                    <input type="text" class="input" name="#" value="<?php echo (is_array($nim) ? $nim[0] : $nim); ?>" readonly>
                                </div>
                                <?php } ?>

                                <div class="input-field">
                                    <label for="">Perihal*</label>
                                    <input type="text" class="input" name="#" placeholder="" value="<?php echo $perihal; ?>" readonly>
                                </div>

                                <div class="input-field">
                                    <label for="">Nomor Surat</label>
                                    <input type="text" class="input" name="#" value="<?php echo $no_surat; ?>" readonly>
                                </div>

                                <div class="input-field">
                                    <label for="">Tanggal Surat</label>
                                    <input type="text" class="input" name="#" value="<?php echo $tanggal_surat; ?>" readonly>
                                </div>

                                <div class="input-field">
                                    <label for="">Tujuan Surat</label>
                                    <input type="text" class="input" name="#" placeholder="" value="<?php echo $tujuan_surat; ?>" readonly>
                                </div>

                                <div class="input-field">
                                    <label for="">No Telepon*</label>
                                    <input type="text" class="input" name="#" placeholder="" value="<?php echo $no_telepon; ?>" readonly>
                                </div>

                                <?php if ($_SESSION['akses'] == "Humas") { ?>
                                    <div class="input-field">
                                        <label for="">Email*</label>
                                        <input type="text" class="input" name="#" placeholder="" value="<?php echo $suratelektrik; ?>" readonly>
                                    </div>
                                <?php } ?>
                                
                                <div class="input-field">
                                    <label for="">Deskripsi Singkat*</label>
                                    <input type="text" class="input" name="#" placeholder="" value="<?php echo $deskripsi; ?>" readonly>
                                </div>


                            <div class="input-field">
                                <label> </label>
                                <div class="input" style="color: black; text-align: center; background-color: rgba(0, 0, 0, 0); border: none"> 
                                <div class="lihat">
                                    <?php if ($file_berkas_exists): ?>
                                    <?php
                                    // Path untuk berkas
                                    $file_berkas_path = "uploads/berkas/" . $file_berkas_name;
                                    ?>
                                    <button type="button" onclick="lihatBerkas('<?php echo $file_berkas_path; ?>')">Lihat Berkas</button>
                                <?php else: ?>
                                    <p>Tidak ada berkas yang tersedia.</p>
                                <?php endif; ?>
                                
                            
                            <!--button laporan--> 
                                <?php if ($file_laporan_exists): ?>
                                    <?php
                                    // Path untuk laporan
                                    $file_laporan_path = "uploads/laporan/" . $file_laporan_name;
                                    ?>
                                    <button type="button" onclick="lihatLaporan('<?php echo $file_laporan_path; ?>')">Lihat Laporan</button>
                                <?php else: ?>
                                    <p>Tidak ada laporan yang tersedia.</p>
                                <?php endif; ?>
                            </div>

                            <!-- Modal untuk tampilan berkas -->
                                <div id="modalBerkas" class="modal">
                                    <span class="close" onclick="closeModal()">&times;</span>
                                    <div class="modal-content-file">
                                        <h2> PREVIEW BERKAS</h2>
                                        <iframe id="berkasFrame" frameborder="0"></iframe>
                                    </div>
                                </div>
                                    

                            <!-- Modal untuk tampilan laporan -->
                                <div id="modalLaporan" class="modal" <?php if (!$file_laporan_exists) echo 'style="display: none;"'; ?>>
                                    <span class="close" onclick="closeModalLaporan()">&times;</span>
                                    <div class="modal-content-file">        
                                            <h2> PREVIEW LAPORAN </h2>
                                            <iframe id="laporanFrame" frameborder="0"></iframe>
                                        </div>
                                    </div>
                                </div>

                            </div>
                              
                                <!-- form disposisi bawah -->
                                <?php include "disposisiBawah.php" ?>     
                        </form>
                </div>
            </div>
            <?php include './footer.php'; ?>
        </div>
        <script>
    // Get the modal
var accMdl = document.getElementById("accModal");

// Get the button that opens the modal
var accBtn = document.getElementById("accModalBtn");

// When the user clicks the button, toggle the modal
accBtn.onclick = function() {
    accMdl.style.display === "block" ? closeModalAcc() : openModalAcc();
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == accMdl) {
        closeModalAcc();
    }
}

// Function to open modal
function openModalAcc() {
    accMdl.style.display = "block";
}

// Function to close modal
function closeModalAcc() {
    accMdl.style.display = "none";
}
</script>
        <script src="js/dashboard-js.js"></script>
        <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
        
                <!-- Modal script -->

<script>
    // Function to display file modal and set iframe source for files
    function lihatBerkas(filePath) {
        document.getElementById("berkasFrame").src = filePath;
        document.getElementById("modalBerkas").style.display = "block";
    }

    // Function to close file modal
    function closeModal() {
        document.getElementById("modalBerkas").style.display = "none";
    }

    // Function to display report modal and set iframe source for reports
    function lihatLaporan(filePath) {
        // Close file modal if it's open
        closeModal();
        // Set iframe source and display report modal
        document.getElementById("laporanFrame").src = filePath;
        document.getElementById("modalLaporan").style.display = "block";
    }

    // Function to close report modal
    function closeModalLaporan() {
        document.getElementById("modalLaporan").style.display = "none";
    }
</script>

<!-- Close modal script -->
<script>
    // Function to close modals when clicking outside
    window.onclick = function(event) {
        var modalBerkas = document.getElementById("modalBerkas");
        var modalLaporan = document.getElementById("modalLaporan");
        if (event.target == modalBerkas) {
            modalBerkas.style.display = "none";
        }
        if (event.target == modalLaporan) {
            modalLaporan.style.display = "none";
        }
    }
</script>

        <script>
            var dt = new Date();
            document.getElementById("tanggalwaktu").innerHTML = (("0"+dt.getDate()).slice(-2)) +"/"+ (("0"+(dt.getMonth()+1)).slice(-2)) +"/"+ (dt.getFullYear());
        </script>

        <script>  
            function goBack(){
                window.history.back();
            }
        </script>
        
    </body>
</html>